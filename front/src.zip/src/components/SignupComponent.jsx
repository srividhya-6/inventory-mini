import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

export default function SignupComponent(){
   
    return (
        <form>
             <TextField id="filled-basic" label="Name" variant="filled" /><br /><br />
             <TextField id="filled-basic" label="Email" variant="filled" /><br /><br />
             <TextField id="filled-basic" label="Password" variant="filled" /><br /><br />

             <TextField id="filled-basic" label="Role" variant="filled" /><br /><br />
             <Button variant="contained">Login</Button>
        </form>
    )
}