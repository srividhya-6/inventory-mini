import { useState,useEffect } from "react";
import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import axios from 'axios'
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));
export default function ProductComponent(){
    const navigate=useNavigate()
    let [products,setProducts]=useState([]);
    useEffect(function updateProducts(){
        axios.get("http://localhost:8082/api/products").then(response=> {
            console.log(response.data);
            setProducts(response.data)})
    },[])
    function deleteProduct(id){
        axios.delete(`http://localhost:8082/api/products/${id}`).then(res=>{
            console.log(res.data);
            setProducts(products.filter((p)=>p._id!=id))
        })
    }
    return(
        <>
            <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
           
            <StyledTableCell align="right">Name</StyledTableCell>
            <StyledTableCell align="right">Description</StyledTableCell>
            <StyledTableCell align="right">Price</StyledTableCell>
            <StyledTableCell align="right">Quantity</StyledTableCell>
            <StyledTableCell align="right">Category</StyledTableCell>
            <StyledTableCell align="right">Action</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {products.map((p)=> (
            <StyledTableRow >
              <StyledTableCell component="th" scope="row">
                {p.name}
              </StyledTableCell>
              <StyledTableCell align="right">{p.description}</StyledTableCell>
              <StyledTableCell align="right">{p.price}</StyledTableCell>
              <StyledTableCell align="right">{p.quantity}</StyledTableCell>
              <StyledTableCell align="right">{p.category}</StyledTableCell>
              <StyledTableCell align="right"><Button variant="contained" size="small" type='submit' onClick={()=>navigate(`/products/edit/${p._id}`)}>Edit</Button>&nbsp;&nbsp;
              <Button variant="contained" size="small" type='submit' onClick={()=>deleteProduct(p._id)}>Delete</Button>
              </StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    
    <form action="/product/new">
    <Button variant="contained" type='submit'>Add Product</Button>
    </form>
        </>
    )
}







// import { useState,useEffect } from "react";
// import axios from 'axios'
// export default function ProductComponent(){
//     let [products,setProducts]=useState([]);
//     useEffect(function updateProducts(){
//         axios.get("http://localhost:8082/api/products").then(response=> {
//             console.log(response.data);
//             setProducts(response.data)})
//     },[])
//     return(
//         <>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>Name</th>
//                         <th>Description</th>
//                         <th>Price</th>
//                         <th>Quantity</th>
//                         <th>Category</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                 {
//                     products.map((p)=>
                        
//                         <tr>
//                             <td>{p.name}</td>
//                             <td>{p.description}</td>
//                             <td>{p.price}</td>
//                             <td>{p.quantity}</td>
//                             <td>{p.category}</td>
//                         </tr>
//                     )
//                 }
//                 </tbody>
//             </table>
//         </>
//     )
// }