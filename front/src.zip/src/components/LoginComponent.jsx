
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useState } from 'react';

export default function LoginComponent(){
    
    return (
        <form action='/products' method='get'>
             <TextField id="filled-basic" label="Email" variant="filled" /><br /><br />
             <TextField id="filled-basic" label="Password" variant="filled" /><br /><br />
             <Button variant="contained" type='submit'>Login</Button>
        </form>
    )
}